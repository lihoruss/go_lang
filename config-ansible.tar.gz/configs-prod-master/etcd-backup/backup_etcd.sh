#!/bin/bash
date=`date +%Y-%m-%d`

etcd_main_host=`ssh backup@s-bnk12-dbcp001.global.bcs "ETCDCTL_API=3 etcdctl endpoint status --write-out=table --endpoints=http://172.17.211.51:2379,http://172.17.211.52:2379,http://172.17.211.53:2379"|  awk '$11 == "true" {print $2}'| sed -r 's/http:\/\///g'| awk -F ":" '{print $1}'`
#echo "etcd_main_host:$etcd_main_host"

ssh backup@"$etcd_main_host" << EOF
etcdctl --endpoints=localhost:2379 snapshot save /tmp/"$date"-etcd_backup.db && ~/.local/bin/mccli --insecure cp /tmp/"$date"-etcd_backup.db minio/etcd
sleep 3
~/.local/bin/mccli --insecure ls minio/etcd > ~/.local/bkcp.log
EOF

check=`ssh backup@"$etcd_main_host" "cat ~/.local/bkcp.log | grep "$date"-etcd_backup.db | wc -l"`

if [[ "$check" -eq 1 ]]; then
   echo 'backup etcd successfully saved'
   ssh backup@"$etcd_main_host" "~/.local/bin/mccli --insecure rm -r --force --older-than 7d0h00m  minio/etcd"
else
   echo 'backup etcd was not saved!!!'
fi
exit
