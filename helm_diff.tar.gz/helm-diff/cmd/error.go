package cmd

// Error to report errors
type Error struct {
	error
	Code int
}
